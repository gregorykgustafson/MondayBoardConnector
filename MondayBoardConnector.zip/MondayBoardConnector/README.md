# MondayBoardConnector Sample

This sample provides a simple data source extension that can be run in Visual Studio, and loaded in Power BI Desktop. As an overview, this sample shows the following:

* Connects to Monday.com API and queries the data from a board into a table. This does not include board comments.
